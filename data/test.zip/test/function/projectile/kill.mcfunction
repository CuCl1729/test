
tag @s add kill