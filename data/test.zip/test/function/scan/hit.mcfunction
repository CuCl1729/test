
tag @s add hit
